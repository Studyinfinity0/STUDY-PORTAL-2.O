import { useEffect, useRef, useState, useCallback, useImperativeHandle, forwardRef } from "react";
import { RefreshCw, ArrowDownToLine } from "lucide-react";
import { HLSDownloader, DownloadProgress } from "@/lib/hlsDownloader";
import { apiUrl } from "@/lib/apiUrl";
import { NetworkPing } from "@/components/NetworkPing";

import { PW_API } from "@/lib/pwApiStore";
import { decodePwMarco } from "@/lib/pwmarco";
const PROXY_BASE = apiUrl("/api");
const ACCENT = "#5a4bda";

interface DrmCache { hlsUrl: string; clearKeys?: Record<string, string>; }
const drmCache = new Map<string, DrmCache>();

function formatTime(secs: number): string {
  if (!isFinite(secs) || secs < 0) return "0:00";
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

const RESUME_KEY = (id: string) => `pw-resume-${id}`;
interface QualityTrack { height: number; bandwidth: number; raw: any; }
type Status = "loading" | "decrypting" | "ready" | "error";
type SettingsPanel = "main" | "speed" | "quality";
const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

export interface DrmPlayerProps {
  batchId: string;
  subjectId: string;
  childId: string;
  poster?: string;
  title?: string;
  videoType?: string;
  topicId?: string;
  onOpenTimeline?: () => void;
  onOpenSlides?: () => void;
  attachments?: { name: string; url: string }[];
}

export interface DrmPlayerRef {
  seekTo: (time: number) => void;
}

function RwSvg() {
  return (
    <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
      <path fill="white" d="M9.015 13.232a1.109 1.109 0 0 1 1.475-.125 1.001 1.001 0 0 1 .21 1.407A10.97 10.97 0 0 0 8.153 21.56c0 2.192.66 4.336 1.9 6.176a11.723 11.723 0 0 0 5.09 4.195c2.083.898 4.391 1.2 6.648.868a12.065 12.065 0 0 0 6.072-2.738 11.314 11.314 0 0 0 3.55-5.465c.609-2.112.569-4.348-.115-6.44a11.357 11.357 0 0 0-3.74-5.346 12.1 12.1 0 0 0-6.165-2.538l1.454 1.2a1.006 1.006 0 0 1 .118 1.457 1.098 1.098 0 0 1-.735.358 1.106 1.106 0 0 1-.783-.245L17.68 9.94a1.04 1.04 0 0 1-.278-.354 1 1 0 0 1 .278-1.217l3.768-3.101a1.09 1.09 0 0 1 1.66.571 1.04 1.04 0 0 1-.26.317l-1.622 1.337a14.335 14.335 0 0 1 7.422 2.818 13.46 13.46 0 0 1 4.611 6.253c.873 2.47.978 5.13.303 7.655a13.348 13.348 0 0 1-4.106 6.57 14.243 14.243 0 0 1-7.178 3.35c-2.68.423-5.432.09-7.919-.961a13.867 13.867 0 0 1-6.084-4.958A13.051 13.051 0 0 1 6 21.559c-.01-3.024 1.053-5.961 3.015-8.328Z"/>
      <path fill="white" d="M16.02 12.927a1.128 1.128 0 0 1-1.536.112l-3.812-3.101a1.032 1.032 0 0 1-.28-.352.991.991 0 0 1 0-.866c.065-.136.16-.256.28-.352l3.813-3.102a1.141 1.141 0 0 1 1.555.093.991.991 0 0 1-.14 1.477l-2.845 2.318 2.847 2.316a.996.996 0 0 1-.144 1.14.883.883 0 0 1-.738.316Z"/>
      <text x="20.5" y="27" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" fontFamily="sans-serif">10</text>
    </svg>
  );
}

function FwSvg() {
  return (
    <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
      <path fill="white" d="M30.99 13.236a1.11 1.11 0 0 0-1.496-.15 1.003 1.003 0 0 0-.195 1.43 10.965 10.965 0 0 1 2.548 7.045c.001 2.192-.659 4.337-1.899 6.177a11.726 11.726 0 0 1-5.091 4.196 12.303 12.303 0 0 1-6.65.868 12.071 12.071 0 0 1-6.076-2.737 11.313 11.313 0 0 1-3.55-5.465c-.61-2.112-.57-4.348.114-6.44a11.356 11.356 0 0 1 3.74-5.346 12.107 12.107 0 0 1 6.169-2.538l-1.459 1.2a1.008 1.008 0 0 0-.09 1.433 1.11 1.11 0 0 0 1.49.137l3.77-3.101a1.04 1.04 0 0 0 .278-.353 1 1 0 0 0-.277-1.217l-3.77-3.1a1.12 1.12 0 0 0-1.677.405.995.995 0 0 0 .424.989l1.623 1.337a14.34 14.34 0 0 0-7.421 2.82 13.457 13.457 0 0 0-4.61 6.253 12.916 12.916 0 0 0-.299 7.653 13.345 13.345 0 0 0 4.107 6.567 14.248 14.248 0 0 0 7.18 3.346c2.68.424 5.432.09 7.919-.96 2.486-1.051 4.6-2.774 6.085-4.957a13.045 13.045 0 0 0 2.273-7.342c.012-3.023-1.05-5.96-3.012-8.326Z"/>
      <path fill="white" d="M24.029 12.931a1.107 1.107 0 0 0 1.52.112l3.77-3.1a1.04 1.04 0 0 0 .277-.353 1 1 0 0 0-.278-1.217l-3.77-3.1a1.12 1.12 0 0 0-1.677.405.993.993 0 0 0 .424.989l2.814 2.316-2.815 2.316a1.007 1.007 0 0 0-.118 1.457Z"/>
      <text x="20.5" y="27" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold" fontFamily="sans-serif">10</text>
    </svg>
  );
}

function VolumeIcon({ level }: { level: "off" | "low" | "high" }) {
  if (level === "off") return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06ZM17.25 9.75l4.5 4.5m0-4.5-4.5 4.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
  if (level === "low") return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06ZM15.932 7.757a.75.75 0 0 1 1.061 0 6 6 0 0 1 0 8.486.75.75 0 0 1-1.06-1.061 4.5 4.5 0 0 0 0-6.364.75.75 0 0 1 0-1.06Z"/>
    </svg>
  );
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06ZM18.584 5.106a.75.75 0 0 1 1.06 0c3.808 3.807 3.808 9.98 0 13.788a.75.75 0 0 1-1.06-1.06 8.25 8.25 0 0 0 0-11.668.75.75 0 0 1 0-1.06Z"/><path d="M15.932 7.757a.75.75 0 0 1 1.061 0 6 6 0 0 1 0 8.486.75.75 0 0 1-1.06-1.061 4.5 4.5 0 0 0 0-6.364.75.75 0 0 1 0-1.06Z"/>
    </svg>
  );
}

function CBtn({ onClick, children, title, className = "" }: { onClick?: (e: React.MouseEvent) => void; children: React.ReactNode; title?: string; className?: string }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`flex items-center justify-center min-w-[44px] min-h-[44px] rounded-lg bg-transparent border-none cursor-pointer text-white transition-transform active:scale-85 outline-none ${className}`}
    >
      {children}
    </button>
  );
}

export const DrmPlayer = forwardRef<DrmPlayerRef, DrmPlayerProps>(({
  batchId, subjectId, childId, poster, title, videoType, topicId,
  onOpenTimeline, onOpenSlides, attachments
}, ref) => {
  const videoRef      = useRef<HTMLVideoElement>(null);
  const playerRef     = useRef<any>(null);
  const containerRef  = useRef<HTMLDivElement>(null);
  const seekBarRef    = useRef<HTMLDivElement>(null);
  const hideTimerRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const resumeSaveRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastTapRef    = useRef<{ time: number; x: number } | null>(null);
  const touchSeekRef  = useRef(false);
  const menuRef       = useRef<HTMLDivElement>(null);
  const stallTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recoveryAttemptsRef = useRef(0);

  const [status, setStatus]         = useState<Status>("loading");
  const [statusMsg, setStatusMsg]   = useState("Initializing…");
  const [loadProgress, setLoadProgress] = useState(0);
  const [error, setError]           = useState("");
  const [attempt, setAttempt]       = useState(0);

  useImperativeHandle(ref, () => ({
    seekTo: (t: number) => {
      if (videoRef.current) {
        videoRef.current.currentTime = t;
        if (videoRef.current.paused) videoRef.current.play().catch(() => {});
      }
    }
  }));

  const [playing, setPlaying]             = useState(false);
  const [currentTime, setCurrentTime]     = useState(0);
  const [duration, setDuration]           = useState(0);
  const [buffered, setBuffered]           = useState(0);
  const [volume, setVolume]               = useState(1);
  const [muted, setMuted]                 = useState(false);
  const [speed, setSpeed]                 = useState(1);
  const [fullscreen, setFullscreen]       = useState(false);
  const [showControls, setShowControls]   = useState(true);
  const [showSettings, setShowSettings]   = useState(false);
  const [settingsPanel, setSettingsPanel] = useState<SettingsPanel>("main");
  const [seeking, setSeeking]             = useState(false);
  const [qualities, setQualities]         = useState<QualityTrack[]>([]);
  const [activeQuality, setActiveQuality] = useState<number | "auto">("auto");
  const [seekTooltip, setSeekTooltip]     = useState<{ time: number; pct: number } | null>(null);

  // Download state
  const [downloadState, setDownloadState] = useState<DownloadProgress | null>(null);
  const downloaderRef = useRef<HLSDownloader | null>(null);
  const [buffering, setBuffering]         = useState(false);
  const [menuOpen, setMenuOpen]           = useState(false);
  const [topMenuPanel, setTopMenuPanel]   = useState<"main" | "download" | "attachments">("main");
  const [isMobile, setIsMobile]           = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // Simulate loading progress
  useEffect(() => {
    if (status === "loading" || status === "decrypting") {
      setLoadProgress(0);
      const interval = setInterval(() => {
        setLoadProgress(prev => {
          if (prev < 40) return prev + Math.floor(Math.random() * 15) + 5; // fast to 40
          if (prev < 80) return prev + Math.floor(Math.random() * 5) + 2;  // med to 80
          if (prev < 99) return prev + 1; // slow to 99
          return prev;
        });
      }, 300);
      return () => clearInterval(interval);
    } else if (status === "ready") {
      setLoadProgress(100);
    }
  }, [status, attempt]);

  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => setShowControls(false), 4000);
  }, []);

  const scheduleRecovery = useCallback((message: string) => {
    if (reconnectTimerRef.current || recoveryAttemptsRef.current >= 2 || !navigator.onLine) {
      setStatus("error");
      setError(message);
      return;
    }
    const delay = Math.min(1500 * (recoveryAttemptsRef.current + 1), 6000);
    recoveryAttemptsRef.current += 1;
    setStatusMsg(`Connection interrupted — reconnecting in ${Math.ceil(delay / 1000)}s…`);
    setStatus("loading");
    reconnectTimerRef.current = setTimeout(() => {
      reconnectTimerRef.current = null;
      setAttempt((current) => current + 1);
    }, delay);
  }, []);

  useEffect(() => {
    if (!batchId || !childId) return;
    let cancelled = false;

    async function setup() {
      setStatus("loading");
      setError("");
      setPlaying(false);
      setCurrentTime(0);
      setDuration(0);
      setQualities([]);
      setActiveQuality("auto");
      
      if (downloaderRef.current) {
        downloaderRef.current.cancel();
        downloaderRef.current = null;
        setDownloadState(null);
      }

      try {
        const cacheKey = `${batchId}:${subjectId}:${childId}`;
        let cached = drmCache.get(cacheKey);

        if (cached && cached.hlsUrl.includes("herokuapp.com") && !cached.clearKeys) {
          cached = undefined;
        }

        if (!cached) {
          setStatusMsg("Fetching video URL…");
          let videoUrl: string | undefined;

          // Try pwmarco API first
          try {
            const apiEndpoint = videoType === "live" ? "/pwmarco-stream-url" : "/pwmarco-video-url";
            const qs = videoType === "live" 
              ? `?parentId=${batchId}&subjectId=${subjectId}&childId=${childId}&urlType=penpencilvdo&videoId=${childId}&topicId=${topicId || childId}`
              : `?batchId=${batchId}&childId=${childId}&subjectId=${subjectId}`;
            
            const pwMarcoRes = await fetch(`${PROXY_BASE}${apiEndpoint}${qs}`);
            if (pwMarcoRes.ok) {
              const data = await pwMarcoRes.json();
              if (data?.v === "1" && data?.d) {
                const decoded = decodePwMarco(data.d);
                if (decoded?.success && decoded?.data?.url) {
                  videoUrl = "https://m.pwmarco.site" + decoded.data.url;
                  if (decoded.data.clearKeys) {
                    cached = { hlsUrl: "", clearKeys: decoded.data.clearKeys };
                  }
                }
              }
            }
          } catch (e) {
            console.error("pwmarco fetch failed", e);
          }

          // Fallback to the slides API if devcoderz didn't provide a URL
          if (!videoUrl) {
            const slidesRes = await fetch(
              `${PW_API}/v1/batches/${batchId}/subject/${subjectId}/schedule/${childId}/slides`
            );
            if (slidesRes.ok) {
              const slidesData = await slidesRes.json();
              videoUrl = slidesData?.data?.url;
            }
          }

          // Fallback to the videos API if the URL wasn't found in slides
          if (!videoUrl) {
            const videoRes = await fetch(
              `${PW_API}/v1/videos/${encodeURIComponent(childId)}`
            );
            if (videoRes.ok) {
              const videoData = await videoRes.json();
              videoUrl = videoData?.data?.videoUrl;
            }
          }

          if (!videoUrl) throw new Error("No video URL in video details");

          const uuidMatch = videoUrl.match(/\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\//);
          let hlsUrl = videoUrl;
          if (uuidMatch && videoUrl.includes("pimaxer")) {
            const uuid = uuidMatch[1];
            hlsUrl = `https://stream.srv-1.pimaxer.in/${uuid}/master.m3u8`;
          }

          if (cancelled) return;

          if (!cached) cached = { hlsUrl };
          else cached.hlsUrl = hlsUrl;

          drmCache.set(cacheKey, cached);
        } else {
          setStatusMsg("Loading from cache…");
        }

        const { hlsUrl, clearKeys } = cached;
        if (cancelled) return;
        setStatus("loading");
        setStatusMsg("Initializing player…");

        const shakaModule = await import("shaka-player");
        const shaka = (shakaModule as any).default ?? shakaModule;
        if (cancelled) return;

        shaka.polyfill.installAll();
        const video = videoRef.current;
        if (!video || cancelled) return;

        if (playerRef.current) {
          await playerRef.current.destroy();
          playerRef.current = null;
        }

        const player = new shaka.Player();
        await player.attach(video);
        playerRef.current = player;
        const config: any = {
          streaming: {
            bufferingGoal: 30,
            rebufferingGoal: 5,
            bufferBehind: 30,
            safeSeekOffset: 3,
            stallEnabled: false,
            retryParameters: {
              maxAttempts: 3,
              baseDelay: 1000,
              backoffFactor: 1.5,
              fuzzFactor: 0.5,
              timeout: 30000,
            },
          },
        };

        if (clearKeys) {
          config.drm = { clearKeys };
        }

        player.configure(config);

        // Intercept and rewrite HLS requests to route through Render backend proxy
        const netEngine = player.getNetworkingEngine();
        if (netEngine) {
          netEngine.registerRequestFilter((type: number, request: any) => {
            const uri = request.uris[0];
            if (!uri) return;

            // Key requests
            if (uri.includes(".key")) {
              const match = uri.match(/pimaxer\.in\/([0-9a-fA-F\-]+)\//);
              if (match) {
                const uuid = match[1];
                request.uris[0] = `https://stream.srv-1.pimaxer.in/${uuid}/hls-key?videoKey=${uuid}&key=enc.key`;
              }
              return;
            }

            // Prevent infinite proxy loops
            if (uri.includes("/api/proxy") || uri.includes(PROXY_BASE + "/proxy")) return;

            // Intercept CDN URLs (devcoderz & PW) to bypass CORS & WAF!
            const cdnHosts = ["herokuapp.com", "cloudfront.net", "pw.live"];
            if (cdnHosts.some((h) => uri.includes(h))) {
              // MUST be an absolute URL, otherwise Shaka resolves it against the MPD's <BaseURL>!
              request.uris[0] = `${window.location.origin}${PROXY_BASE}/proxy?url=${encodeURIComponent(uri)}`;
              return;
            }

          });
        }

        player.addEventListener("error", (event: Event) => {
          if (cancelled) return;
          const detail = (event as any).detail ?? event;
          const code = Number(detail?.code ?? 0);
          const message = detail?.message || `Playback error (code ${code || "?"})`;
          const transient =
            (code >= 7000 && code < 8000) ||
            code === 1001 ||
            code === 1002 ||
            /network|timeout|fetch|load|connection/i.test(message);
          if (transient) scheduleRecovery(message);
          else {
            setStatus("error");
            setError(message);
          }
        });

        player.addEventListener("streaming", () => {
          if (cancelled) return;
          const tracks: QualityTrack[] = [];
          const seen = new Set<number>();
          (player.getVariantTracks() as any[])
            .filter((t) => t.type === "variant")
            .sort((a: any, b: any) => b.height - a.height)
            .forEach((t: any) => {
              if (!seen.has(t.height) && t.height) {
                seen.add(t.height);
                tracks.push({ height: t.height, bandwidth: t.bandwidth, raw: t });
              }
            });
          setQualities(tracks);
        });

        await player.load(hlsUrl);

        if (!cancelled) {
          recoveryAttemptsRef.current = 0;
          setStatus("ready");
          try {
            const saved = parseFloat(localStorage.getItem(RESUME_KEY(childId)) || "0");
            if (saved > 0 && saved < (video.duration || Infinity) - 5) {
              video.currentTime = saved;
            }
          } catch {}
          video.play().catch(() => {});
        }
      } catch (err: unknown) {
        if (!cancelled) {
          const e = err as any;
          const message = e instanceof Error ? e.message : e?.message ? String(e.message) : "Unknown error";
          if (/network|timeout|fetch|load|connection|failed/i.test(message)) scheduleRecovery(message);
          else {
            setStatus("error");
            setError(message);
          }
        }
      }
    }

    setup();
    return () => {
      cancelled = true;
      if (stallTimerRef.current) clearTimeout(stallTimerRef.current);
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      if (playerRef.current) {
        playerRef.current.destroy().catch(() => {});
        playerRef.current = null;
      }
    };
  }, [batchId, subjectId, childId, attempt]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime     = () => setCurrentTime(video.currentTime);
    const onDur      = () => setDuration(video.duration);
    const onPlay     = () => { setPlaying(true); setBuffering(false); };
    const onPause    = () => setPlaying(false);
    const onVol      = () => { setVolume(video.volume); setMuted(video.muted); };
    const onProgress = () => {
      if (video.buffered.length > 0) setBuffered(video.buffered.end(video.buffered.length - 1));
    };
     const onWait     = () => {
       setBuffering(true);
       if (stallTimerRef.current) clearTimeout(stallTimerRef.current);
       const wasPlaying = !video.paused;
       stallTimerRef.current = setTimeout(() => {
         stallTimerRef.current = null;
         if (wasPlaying && !video.paused && video.readyState < 3) {
           try { localStorage.setItem(RESUME_KEY(childId), String(video.currentTime)); } catch {}
           scheduleRecovery("Video is taking too long to buffer.");
         }
       }, 30000);
     };
     const onCanPlay  = () => {
       setBuffering(false);
       if (stallTimerRef.current) clearTimeout(stallTimerRef.current);
       stallTimerRef.current = null;
     };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("durationchange", onDur);
    video.addEventListener("loadedmetadata", onDur);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("volumechange", onVol);
    video.addEventListener("progress", onProgress);
    video.addEventListener("waiting", onWait);
    video.addEventListener("canplay", onCanPlay);
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("durationchange", onDur);
      video.removeEventListener("loadedmetadata", onDur);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("volumechange", onVol);
      video.removeEventListener("progress", onProgress);
      video.removeEventListener("waiting", onWait);
      video.removeEventListener("canplay", onCanPlay);
    };
  }, [status, childId, scheduleRecovery]);

  useEffect(() => {
    if (status !== "ready") return;
    resumeSaveRef.current = setInterval(() => {
      const v = videoRef.current;
      if (v && v.currentTime > 2) {
        try { localStorage.setItem(RESUME_KEY(childId), String(v.currentTime)); } catch {}
      }
    }, 5000);
    return () => { if (resumeSaveRef.current) clearInterval(resumeSaveRef.current); };
  }, [status, childId]);

  useEffect(() => {
    const onFS = () => setFullscreen(!!(
      document.fullscreenElement ||
      (document as any).webkitFullscreenElement ||
      (document as any).mozFullScreenElement
    ));
    document.addEventListener("fullscreenchange", onFS);
    document.addEventListener("webkitfullscreenchange", onFS);
    document.addEventListener("mozfullscreenchange", onFS);
    const video = videoRef.current;
    const onVideoFS = () => setFullscreen(true);
    const onVideoExitFS = () => setFullscreen(false);
    video?.addEventListener("webkitbeginfullscreen", onVideoFS);
    video?.addEventListener("webkitendfullscreen", onVideoExitFS);
    return () => {
      document.removeEventListener("fullscreenchange", onFS);
      document.removeEventListener("webkitfullscreenchange", onFS);
      document.removeEventListener("mozfullscreenchange", onFS);
      video?.removeEventListener("webkitbeginfullscreen", onVideoFS);
      video?.removeEventListener("webkitendfullscreen", onVideoExitFS);
    };
  }, []);

  useEffect(() => {
    if (status !== "ready") return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const v = videoRef.current;
      if (!v) return;
      switch (e.key) {
        case " ": case "k":
          e.preventDefault(); v.paused ? v.play() : v.pause(); resetHideTimer(); break;
        case "ArrowRight": case "l":
          e.preventDefault(); v.currentTime = Math.min(v.currentTime + 10, v.duration); resetHideTimer(); break;
        case "ArrowLeft": case "j":
          e.preventDefault(); v.currentTime = Math.max(v.currentTime - 10, 0); resetHideTimer(); break;
        case "ArrowUp":
          e.preventDefault(); v.volume = Math.min(v.volume + 0.1, 1); break;
        case "ArrowDown":
          e.preventDefault(); v.volume = Math.max(v.volume - 0.1, 0); break;
        case "m": v.muted = !v.muted; break;
        case "f": toggleFullscreen(); break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [status, resetHideTimer]);

  function togglePlay() {
    const v = videoRef.current;
    if (!v) return;
    v.paused ? v.play() : v.pause();
    resetHideTimer();
  }

  function toggleMute() {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
  }

  function setVideoVolume(val: number) {
    const v = videoRef.current;
    if (!v) return;
    v.volume = val;
    v.muted = val === 0;
  }

  function setVideoSpeed(s: number) {
    const v = videoRef.current;
    if (!v) return;
    v.playbackRate = s;
    setSpeed(s);
    setSettingsPanel("main");
    setShowSettings(false);
  }

  function selectQuality(height: number | "auto") {
    if (!playerRef.current) return;
    if (height === "auto") {
      playerRef.current.configure({ abr: { enabled: true } });
      setActiveQuality("auto");
    } else {
      playerRef.current.configure({ abr: { enabled: false } });
      const tracks = playerRef.current.getVariantTracks();
      const best = (tracks as any[]).filter((t) => t.height === height).sort((a: any, b: any) => b.bandwidth - a.bandwidth)[0];
      if (best) playerRef.current.selectVariantTrack(best, true);
      setActiveQuality(height);
    }
    setSettingsPanel("main");
    setShowSettings(false);
  }

  function handleDownload(quality: number | null = null) {
    if (downloaderRef.current || status !== "ready" || !videoRef.current) return;
    setMenuOpen(false);
    setTopMenuPanel("main");

    // Get the base video URL from shaka player
    const uuidMatch = videoRef.current.src?.match(/\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\//) 
      || playerRef.current?.getAssetUri()?.match(/\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\//);
    
    // We can extract it from playerRef or just use the batchId/childId for name
    const manifestUrl = playerRef.current?.getAssetUri();
    if (!manifestUrl) {
      alert("Unable to fetch video URL for download.");
      return;
    }

    let uuid = "";
    if (uuidMatch) uuid = uuidMatch[1];
    
    // Fallback uuid extraction from pimaxer domain
    if (!uuid) {
      const match2 = manifestUrl.match(/streama\.pimaxer\.in\/([0-9a-fA-F\-]+)\//);
      if (match2) uuid = match2[1];
    }

    if (!uuid) {
      alert("Could not identify video UUID for decryption.");
      return;
    }

    const downloader = new HLSDownloader(manifestUrl, uuid, (prog) => {
      setDownloadState(prog);
      if (prog.status === "done" || prog.status === "error") {
        setTimeout(() => {
          if (downloaderRef.current === downloader) {
            downloaderRef.current = null;
            setDownloadState(null);
          }
        }, 3000); // clear UI after 3s
      }
    });

    downloaderRef.current = downloader;
    downloader.start(title ? `${title.replace(/[^a-zA-Z0-9 ]/g, "")}.mp4` : "lecture.mp4", quality);
  }

  function toggleFullscreen() {
    const el = containerRef.current;
    const video = videoRef.current;
    if (!el || !video) return;
    const isFS = !!(
      document.fullscreenElement ||
      (document as any).webkitFullscreenElement ||
      (document as any).mozFullScreenElement
    );
    if (!isFS) {
      // iOS Safari requires fullscreen on the video element itself
      if ((video as any).webkitEnterFullscreen) {
        (video as any).webkitEnterFullscreen();
      } else if (el.requestFullscreen) {
        el.requestFullscreen().catch(() => {});
      } else if ((el as any).webkitRequestFullscreen) {
        (el as any).webkitRequestFullscreen();
      } else if ((el as any).mozRequestFullScreen) {
        (el as any).mozRequestFullScreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      } else if ((document as any).webkitExitFullscreen) {
        (document as any).webkitExitFullscreen();
      } else if ((document as any).mozCancelFullScreen) {
        (document as any).mozCancelFullScreen();
      }
    }
  }

  function skip(secs: number) {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Math.max(0, Math.min(v.currentTime + secs, v.duration));
    resetHideTimer();
  }

  function getSeekRatio(clientX: number) {
    const bar = seekBarRef.current;
    if (!bar || !duration) return null;
    const rect = bar.getBoundingClientRect();
    return Math.max(0, Math.min((clientX - rect.left) / rect.width, 1));
  }

  function onSeekClick(e: React.MouseEvent<HTMLDivElement>) {
    const ratio = getSeekRatio(e.clientX);
    if (ratio === null) return;
    videoRef.current!.currentTime = ratio * duration;
    resetHideTimer();
  }

  function onSeekMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const bar = seekBarRef.current;
    if (!bar) return;
    const rect = bar.getBoundingClientRect();
    const pct = Math.max(0, Math.min((e.clientX - rect.left) / rect.width, 1));
    setSeekTooltip({ time: pct * duration, pct });
    if (seeking) videoRef.current!.currentTime = pct * duration;
  }

  function onSeekTouchStart(e: React.TouchEvent<HTMLDivElement>) {
    e.stopPropagation();
    touchSeekRef.current = true;
    setSeeking(true);
    const ratio = getSeekRatio(e.touches[0].clientX);
    if (ratio !== null) videoRef.current!.currentTime = ratio * duration;
  }

  function onSeekTouchMove(e: React.TouchEvent<HTMLDivElement>) {
    e.stopPropagation();
    if (!touchSeekRef.current) return;
    const ratio = getSeekRatio(e.touches[0].clientX);
    if (ratio !== null) videoRef.current!.currentTime = ratio * duration;
  }

  function onSeekTouchEnd(e: React.TouchEvent<HTMLDivElement>) {
    e.stopPropagation();
    touchSeekRef.current = false;
    setSeeking(false);
  }

  function handleTap(e: React.TouchEvent<HTMLDivElement>) {
    if (touchSeekRef.current) return;
    e.preventDefault();
    const now = Date.now();
    const touch = e.changedTouches[0];
    const rect = containerRef.current!.getBoundingClientRect();
    const relX = touch.clientX - rect.left;

    if (lastTapRef.current && now - lastTapRef.current.time < 280) {
      const side = relX < rect.width / 2 ? "left" : "right";
      skip(side === "right" ? 10 : -10);
      lastTapRef.current = null;
    } else {
      lastTapRef.current = { time: now, x: relX };
      setTimeout(() => {
        if (lastTapRef.current && Date.now() - lastTapRef.current.time >= 280) {
          setShowControls((v) => { if (!v) resetHideTimer(); return !v; });
          lastTapRef.current = null;
        }
      }, 300);
    }
  }

  const played = duration ? currentTime / duration : 0;
  const buf    = duration ? buffered / duration : 0;
  const qualityLabel = activeQuality === "auto" ? "Auto" : `${activeQuality}p`;
  const speedLabel = speed === 1 ? "Normal" : `${speed}x`;
  const volumeLevel: "off" | "low" | "high" = (muted || volume === 0) ? "off" : volume < 0.5 ? "low" : "high";

  const hasPanel = !!(onOpenTimeline || onOpenSlides || (attachments && attachments.length > 0));

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full bg-black select-none overflow-hidden"
      style={{ fontFamily: "'DM Sans', -apple-system, sans-serif" }}
      onMouseMove={resetHideTimer}
      onMouseLeave={() => { if (hideTimerRef.current) clearTimeout(hideTimerRef.current); if (playing) setShowControls(false); }}
      onClick={(e) => { if (status === "ready" && !isMobile) { e.stopPropagation(); togglePlay(); } }}
      onTouchEnd={status === "ready" ? handleTap : undefined}
    >
      <video
        ref={videoRef}
        poster={poster}
        className="absolute inset-0 w-full h-full object-contain bg-black"
        style={{ opacity: status === "ready" ? 1 : 0, transition: "opacity 0.3s", display: "block", outline: "none" }}
        playsInline
        preload="auto"
      />

      {(status === "loading" || status === "decrypting") && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-5" style={{ background: "rgba(10, 10, 10, 0.9)" }}>
          <div className="relative flex items-center justify-center z-10">
            {/* Minimalist outer rotating ring */}
            <svg className="absolute w-32 h-32 animate-spin" viewBox="0 0 100 100" style={{ animationDuration: '8s' }}>
              <circle cx="50" cy="50" r="48" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" strokeDasharray="2 10" />
            </svg>
            
            <svg className="w-28 h-28 transform -rotate-90" viewBox="0 0 100 100">
              <defs>
                <linearGradient id="pwxSimpleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#818cf8" />
                  <stop offset="100%" stopColor="#c084fc" />
                </linearGradient>
              </defs>
              {/* Clean background track */}
              <circle cx="50" cy="50" r="44" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="3" />
              {/* Elegant Progress Circle */}
              <circle
                cx="50"
                cy="50"
                r="44"
                fill="none"
                stroke="url(#pwxSimpleGradient)"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeDasharray="276.46"
                strokeDashoffset={276.46 - (loadProgress / 100) * 276.46}
                className="transition-all duration-300 ease-out"
              />
            </svg>
            
            {/* Clean Typography */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-white/70 text-[10px] font-bold tracking-[0.15em] uppercase mb-0.5">PWX</span>
              <span className="text-white font-semibold text-2xl tracking-tight">
                {loadProgress}<span className="text-[11px] text-white/50 ml-0.5 font-medium">%</span>
              </span>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-1.5 z-10 mt-1">
            <p className="text-[12px] text-white/70 font-medium tracking-wide">
              {statusMsg}
            </p>
          </div>
        </div>
      )}

      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-5 text-center" style={{ background: "rgba(0,0,0,.88)" }}>
          <span className="text-4xl">⚠️</span>
          <p className="text-sm text-[#ff6584] max-w-[300px] leading-relaxed">{error}</p>
          <button
            onClick={(e) => { e.stopPropagation(); recoveryAttemptsRef.current = 0; setAttempt((a) => a + 1); }}
            className="flex items-center gap-2 px-5 py-2 rounded-lg text-white text-sm font-medium"
            style={{ background: ACCENT }}
          >
            <RefreshCw className="w-4 h-4" />
            Retry
          </button>
        </div>
      )}

      {/* Download Progress Overlay */}
      {downloadState && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-black/80 backdrop-blur-md rounded-xl px-4 py-3 flex flex-col items-center min-w-[200px] border border-white/10 shadow-2xl">
          <div className="text-white text-sm font-semibold mb-2">
            {downloadState.status === "fetching_manifest" && "Starting Download..."}
            {downloadState.status === "fetching_key" && "Fetching Decryption Key..."}
            {downloadState.status === "downloading" && `Downloading (${downloadState.downloaded}/${downloadState.total})`}
            {downloadState.status === "muxing" && "Preparing MP4..."}
            {downloadState.status === "done" && "Download Complete!"}
            {downloadState.status === "error" && "Download Failed"}
          </div>
          {downloadState.status === "downloading" && (
            <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden">
              <div 
                className="h-full bg-[#5A4BDA] transition-all duration-300"
                style={{ width: `${(downloadState.downloaded / downloadState.total) * 100}%` }}
              />
            </div>
          )}
          {downloadState.status === "error" && (
            <p className="text-xs text-red-400 mt-1">{downloadState.error}</p>
          )}
          {downloadState.status !== "done" && downloadState.status !== "error" && (
            <button 
              className="mt-2 text-xs text-white/60 hover:text-white"
              onClick={(e) => { e.stopPropagation(); downloaderRef.current?.cancel(); setDownloadState(null); downloaderRef.current = null; }}
            >
              Cancel
            </button>
          )}
        </div>
      )}

      {buffering && status === "ready" && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-[8]">
          <div className="w-10 h-10 rounded-full border-[3px] animate-spin" style={{ borderColor: `rgba(90,75,218,.18)`, borderTopColor: ACCENT }} />
        </div>
      )}

      {status === "ready" && (
        <div
          className="absolute inset-0 z-20 flex flex-col transition-opacity duration-200"
          style={{ opacity: showControls || !playing ? 1 : 0, pointerEvents: showControls || !playing ? "auto" : "none" }}
          onClick={(e) => e.stopPropagation()}
          onTouchEnd={(e) => e.stopPropagation()}
        >
          {/* Backdrops for popups to close them when clicking outside */}
          {showSettings && (
            <div className="absolute inset-0 z-40" onClick={(e) => { e.stopPropagation(); setShowSettings(false); }} onTouchEnd={(e) => { e.stopPropagation(); setShowSettings(false); }} />
          )}
          {menuOpen && (
            <div className="absolute inset-0 z-40" onClick={(e) => { e.stopPropagation(); setMenuOpen(false); }} onTouchEnd={(e) => { e.stopPropagation(); setMenuOpen(false); }} />
          )}
          {/* ── Header ── */}
          <div
            className="flex items-center gap-1 px-1 pt-1 pb-10 flex-shrink-0"
            style={{ background: "linear-gradient(to bottom, rgba(0,0,0,.88) 0%, transparent 100%)" }}
          >
            <CBtn onClick={() => window.history.back()} title="Back">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/>
              </svg>
            </CBtn>
            <div className="flex-1 min-w-0 text-[13px] font-semibold text-white/90 truncate leading-snug ml-1">{title}</div>
            {hasPanel && (
              <div className="relative flex-shrink-0" ref={menuRef}>
                <CBtn onClick={(e) => { e.stopPropagation(); setMenuOpen((v) => !v); }} title="More options">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                    <path fillRule="evenodd" d="M10.5 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm0 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Zm0 6a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" clipRule="evenodd"/>
                  </svg>
                </CBtn>
                {menuOpen && (
                  <div
                    className="absolute top-full right-0 mt-1 rounded-2xl overflow-hidden min-w-[190px] z-50"
                    style={{ background: "rgba(12,12,20,.98)", border: "1px solid rgba(255,255,255,.1)", boxShadow: "0 8px 40px rgba(0,0,0,.95)" }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    {topMenuPanel === "main" && (
                      <div>
                        {onOpenTimeline && (
                          <button
                            className="w-full flex items-center gap-3 px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                            style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                            onClick={() => { setMenuOpen(false); onOpenTimeline(); }}
                          >
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3.167 5.583a.083.083 0 01.166 0v12.834a.083.083 0 01-.167 0V5.583zM5.667 17.333a1 1 0 001 1h10.666a1 1 0 001-1V6.667a1 1 0 00-1-1H6.667a1 1 0 00-1 1v10.666zm4.888-3.3V9.966L13.945 12l-3.39 2.034zM20.666 5.583a.083.083 0 11.167 0v12.834a.083.083 0 01-.166 0V5.583z"/></svg>
                            Timeline
                          </button>
                        )}
                        {onOpenSlides && (
                          <button
                            className="w-full flex items-center gap-3 px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                            style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                            onClick={() => { setMenuOpen(false); onOpenSlides(); }}
                          >
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                            Slides
                          </button>
                        )}
                        {attachments && attachments.length > 0 && (
                          <button
                            className="w-full flex items-center gap-3 px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                            style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                            onClick={(e) => { e.stopPropagation(); setTopMenuPanel("attachments"); }}
                          >
                            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
                            Attachments
                          </button>
                        )}
                        
                        <button
                          className="w-full flex items-center gap-3 px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                          onClick={(e) => { e.stopPropagation(); setTopMenuPanel("download"); }}
                        >
                          <ArrowDownToLine className="w-4 h-4 text-white/70" />
                          Download Video
                        </button>
                      </div>
                    )}

                    {topMenuPanel === "download" && (
                      <div>
                        <button
                          className="flex items-center gap-2 w-full px-4 py-3 border-none bg-transparent cursor-pointer hover:bg-white/5 transition-colors"
                          style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                          onClick={(e) => { e.stopPropagation(); setTopMenuPanel("main"); }}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                          <span className="text-white text-[14px] font-medium">Select Quality</span>
                        </button>
                        <div className="max-h-[250px] overflow-y-auto no-scrollbar py-1">
                          {qualities.length === 0 ? (
                            <div className="px-4 py-3 text-white/50 text-[13px]">No qualities available</div>
                          ) : (
                            qualities.map((q) => (
                              <button key={q.height}
                                className="w-full flex items-center justify-between px-4 py-3 border-none cursor-pointer text-white text-[13px] transition-colors hover:bg-white/5"
                                style={{ borderBottom: "1px solid rgba(255,255,255,.05)" }}
                                onClick={(e) => { e.stopPropagation(); handleDownload(q.height); }}
                              >
                                <span>{q.height}p</span>
                              </button>
                            ))
                          )}
                        </div>
                      </div>
                    )}

                    {topMenuPanel === "attachments" && (
                      <div>
                        <button
                          className="flex items-center gap-2 w-full px-4 py-3 border-none bg-transparent cursor-pointer hover:bg-white/5 transition-colors"
                          style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                          onClick={(e) => { e.stopPropagation(); setTopMenuPanel("main"); }}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                          <span className="text-white text-[14px] font-medium">Attachments</span>
                        </button>
                        <div className="max-h-[250px] overflow-y-auto no-scrollbar py-1">
                          {attachments?.map((att, i) => (
                            <button key={i}
                              className="w-full flex items-center justify-between px-4 py-3 border-none cursor-pointer text-white text-[13px] transition-colors hover:bg-white/5 text-left"
                              style={{ borderBottom: "1px solid rgba(255,255,255,.05)" }}
                              onClick={(e) => { e.stopPropagation(); setMenuOpen(false); window.open(att.url, '_blank'); }}
                            >
                              <span className="truncate">{att.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── Mid (click to play/pause — desktop, no visible element) ── */}
          <div className="flex-1" />

          {/* ── Footer ── */}
          <div
            className="flex-shrink-0"
            style={{ background: "linear-gradient(to top, rgba(0,0,0,.95) 0%, rgba(0,0,0,.65) 55%, transparent 100%)" }}
          >
            {/* Seekbar */}
            <div className="group px-3 pt-3 pb-0 cursor-pointer relative" onClick={(e) => e.stopPropagation()}>
              {seekTooltip && (
                <div
                  className="absolute -translate-x-1/2 bg-black/90 text-white text-[11px] font-mono px-2 py-0.5 rounded-md pointer-events-none whitespace-nowrap z-10"
                  style={{ left: `calc(${seekTooltip.pct * 100}% + 12px)`, bottom: "calc(100% - 8px)" }}
                >
                  {formatTime(seekTooltip.time)}
                </div>
              )}
              <div
                className="relative h-8 flex items-center"
                ref={seekBarRef}
                onMouseLeave={() => setSeekTooltip(null)}
              >
                {/* Visual track */}
                <div
                  className="absolute inset-x-0 top-1/2 -translate-y-1/2 rounded-full overflow-hidden transition-all duration-150"
                  style={{ height: seeking ? "5px" : "3px" }}
                >
                  <div className="absolute inset-0 rounded-full" style={{ background: "rgba(255,255,255,.2)" }} />
                  <div className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${buf * 100}%`, background: "rgba(255,255,255,.38)" }} />
                  <div className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${played * 100}%`, background: `linear-gradient(90deg, ${ACCENT}, #8b5cf6)` }} />
                </div>
                {/* Thumb */}
                <div
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-[15px] h-[15px] rounded-full bg-white pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ left: `${played * 100}%`, boxShadow: "0 0 8px rgba(90,75,218,.7), 0 1px 4px rgba(0,0,0,.5)" }}
                />
                <input
                  type="range" min={0} max={1000} step={1}
                  value={Math.round(played * 1000)}
                  onChange={(e) => {
                    const p = parseInt(e.target.value) / 1000;
                    if (videoRef.current && duration) videoRef.current.currentTime = p * duration;
                  }}
                  onMouseDown={() => setSeeking(true)}
                  onMouseUp={() => { setSeeking(false); setSeekTooltip(null); }}
                  onMouseMove={onSeekMouseMove}
                  onTouchStart={onSeekTouchStart}
                  onTouchMove={onSeekTouchMove}
                  onTouchEnd={onSeekTouchEnd}
                  onClick={onSeekClick}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
            </div>

            {/* Controls row */}
            <div className="flex items-center px-1.5 pb-2 gap-0">
              {/* Left group */}
              <CBtn onClick={(e) => { e.stopPropagation(); skip(-10); resetHideTimer(); }} title="Rewind 10s">
                <RwSvg />
              </CBtn>
              <CBtn onClick={(e) => { e.stopPropagation(); togglePlay(); }} title={playing ? "Pause" : "Play"}>
                {playing ? (
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                ) : (
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7z"/></svg>
                )}
              </CBtn>
              <CBtn onClick={(e) => { e.stopPropagation(); skip(10); resetHideTimer(); }} title="Forward 10s">
                <FwSvg />
              </CBtn>

              {/* Volume (desktop) */}
              <div className="hidden sm:flex items-center">
                <CBtn onClick={(e) => { e.stopPropagation(); toggleMute(); }} title="Mute (m)">
                  <VolumeIcon level={volumeLevel} />
                </CBtn>
                <input
                  type="range" min={0} max={1} step={0.05}
                  value={muted ? 0 : volume}
                  onChange={(e) => setVideoVolume(parseFloat(e.target.value))}
                  className="w-[68px] cursor-pointer h-[3px] rounded-full"
                  style={{ accentColor: ACCENT }}
                />
              </div>

              {/* Time */}
              <div className="flex items-center ml-2 gap-0.5">
                <span className="text-white font-mono text-[12px] tabular-nums">{formatTime(currentTime)}</span>
                <span className="text-white/35 font-mono text-[12px] mx-0.5">/</span>
                <span className="text-white/55 font-mono text-[12px] tabular-nums">{formatTime(duration)}</span>
                {speed !== 1 && (
                  <span className="ml-1.5 text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ background: "rgba(90,75,218,.85)", color: "#fff" }}>{speed}×</span>
                )}
              </div>

              <div className="flex-1" />

              <NetworkPing accent={ACCENT} />

              {/* Timeline (desktop) */}
              {onOpenTimeline && (
                <CBtn className="hidden lg:flex" onClick={(e) => { e.stopPropagation(); onOpenTimeline(); }} title="Timeline">
                  <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                    <path d="M5.1 10a.5.5 0 0 1 .5-.5h.2a.5.5 0 0 1 .5.5v20a.5.5 0 0 1-.5.5h-.2a.5.5 0 0 1-.5-.5V10Z" fill="white"/>
                    <rect x="10.3" y="10.3" width="19.4" height="19.4" rx="1.2" stroke="white" strokeWidth="1.8" fill="none"/>
                    <path d="M17.2 17l5.2 3-5.2 3V17Z" fill="white"/>
                    <path d="M33.7 10a.5.5 0 0 1 .5-.5h.2a.5.5 0 0 1 .5.5v20a.5.5 0 0 1-.5.5h-.2a.5.5 0 0 1-.5-.5V10Z" fill="white"/>
                  </svg>
                </CBtn>
              )}

              {/* Settings */}
              <div className="relative">
                <CBtn
                  onClick={(e) => { e.stopPropagation(); setShowSettings(!showSettings); setSettingsPanel("main"); }}
                  title="Settings"
                  className={showSettings ? "bg-white/15 hover:bg-white/15" : ""}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                  </svg>
                </CBtn>

                {showSettings && (
                  <div
                    className="absolute bottom-[calc(100%+8px)] right-0 w-[200px] rounded-2xl overflow-hidden z-50"
                    style={{ background: "rgba(12,12,20,.98)", border: "1px solid rgba(255,255,255,.1)", boxShadow: "0 8px 40px rgba(0,0,0,.95)" }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    {settingsPanel === "main" && (
                      <div>
                        <button
                          className="w-full flex items-center justify-between px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                          style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                          onClick={() => setSettingsPanel("speed")}
                        >
                          <span className="text-white/75">Speed</span>
                          <div className="flex items-center gap-1 text-white/50 text-[13px]">
                            <span>{speedLabel}</span>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 18l6-6-6-6"/></svg>
                          </div>
                        </button>
                        {qualities.length > 0 && (
                          <button
                            className="w-full flex items-center justify-between px-4 py-3.5 text-white text-[14px] cursor-pointer bg-transparent border-none text-left hover:bg-white/5 transition-colors"
                            onClick={() => setSettingsPanel("quality")}
                          >
                            <span className="text-white/75">Quality</span>
                            <div className="flex items-center gap-1 text-white/50 text-[13px]">
                              <span>{qualityLabel}</span>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 18l6-6-6-6"/></svg>
                            </div>
                          </button>
                        )}
                      </div>
                    )}
                    {settingsPanel === "speed" && (
                      <div>
                        <button
                          className="flex items-center gap-2 w-full px-4 py-3 border-none bg-transparent cursor-pointer hover:bg-white/5 transition-colors"
                          style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                          onClick={() => setSettingsPanel("main")}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                          <span className="text-white text-[14px] font-semibold">Speed</span>
                        </button>
                        {SPEEDS.map((s) => (
                          <button key={s}
                            className="w-full flex items-center justify-between px-4 py-3 border-none cursor-pointer text-white text-[13px] transition-colors hover:bg-white/5"
                            style={{ background: speed === s ? `rgba(90,75,218,.22)` : "transparent", borderBottom: "1px solid rgba(255,255,255,.05)" }}
                            onClick={() => setVideoSpeed(s)}
                          >
                            <span>{s === 1 ? "Normal" : `${s}×`}</span>
                            {speed === s && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={ACCENT} strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>}
                          </button>
                        ))}
                      </div>
                    )}
                    {settingsPanel === "quality" && (
                      <div>
                        <button
                          className="flex items-center gap-2 w-full px-4 py-3 border-none bg-transparent cursor-pointer hover:bg-white/5 transition-colors"
                          style={{ borderBottom: "1px solid rgba(255,255,255,.07)" }}
                          onClick={() => setSettingsPanel("main")}
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M15 18l-6-6 6-6"/></svg>
                          <span className="text-white text-[14px] font-semibold">Quality</span>
                        </button>
                        {[{ label: "Auto", value: "auto" as const }, ...qualities.map((q) => ({ label: `${q.height}p`, value: q.height as number | "auto" }))].map((opt) => (
                          <button key={opt.value}
                            className="w-full flex items-center justify-between px-4 py-3 border-none cursor-pointer text-white text-[13px] transition-colors hover:bg-white/5"
                            style={{ background: activeQuality === opt.value ? `rgba(90,75,218,.22)` : "transparent", borderBottom: "1px solid rgba(255,255,255,.05)" }}
                            onClick={() => selectQuality(opt.value)}
                          >
                            <span>{opt.label}</span>
                            {activeQuality === opt.value && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={ACCENT} strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Fullscreen */}
              <CBtn onClick={(e) => { e.stopPropagation(); toggleFullscreen(); }} title={fullscreen ? "Exit fullscreen" : "Fullscreen (f)"}>
                {fullscreen ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M8 3v3a2 2 0 01-2 2H3M21 8h-3a2 2 0 01-2-2V3M3 16h3a2 2 0 012 2v3M16 21v-3a2 2 0 012-2h3"/></svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M4 8V4h4M20 8V4h-4M4 16v4h4M20 16v4h-4"/></svg>
                )}
              </CBtn>
            </div>
          </div>
        </div>
      )}

    </div>
  );
});
