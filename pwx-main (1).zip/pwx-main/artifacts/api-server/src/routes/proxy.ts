import { Router } from "express";
import { Readable } from "node:stream";
import { db, siteSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const proxyRouter = Router();

export async function getPwApiUrl() {
  try {
    const [setting] = await db
      .select()
      .from(siteSettingsTable)
      .where(eq(siteSettingsTable.key, "pw_api_url"));
    return (setting?.value as string) || "https://proxy.streamvideo.co.in/fetch/api.penpencil.co";
  } catch (e) {
    return "https://proxy.streamvideo.co.in/fetch/api.penpencil.co";
  }
}

const CDN_HOSTS = [
  "sec-prod-mediacdn.pw.live",
  "prod-mediacdn.pw.live",
  "mediacdn.pw.live",
  "cloudfront.net",          // PW video CDN distributions
  "proxy.primestudy.site",   // learnbyakp stream proxy
  "herokuapp.com",           // devcoderz video stream host
];
const PDF_HOSTS = ["static.pw.live", "pw.live", "cdn.pw.live", "d2bps9p1kiy4ka.cloudfront.net", "testwave.cc"];

function isAllowedCdnHost(hostname: string): boolean {
  return CDN_HOSTS.some((h) => hostname === h || hostname.endsWith(`.${h}`));
}

function injectBaseUrl(mpdXml: string, baseUrl: string): string {
  if (mpdXml.includes("<BaseURL>")) {
    return mpdXml.replace(/<BaseURL>.*?<\/BaseURL>/g, `<BaseURL>${baseUrl}</BaseURL>`);
  }
  return mpdXml.replace(/<Period([^>]*)>/, `<Period$1>\n    <BaseURL>${baseUrl}</BaseURL>`);
}

// Headers to try in order — each mimics a likely whitelisted referrer on PW's CloudFront WAF
const CDN_HEADER_VARIANTS = [
  {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Referer": "https://vidcloud.eu.org/",
    "Origin": "https://vidcloud.eu.org",
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "sec-ch-ua": '"Chromium";v="124","Google Chrome";v="124"',
    "sec-ch-ua-mobile": "?0",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
  },
  {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Referer": "https://www.pw.live/",
    "Origin": "https://www.pw.live",
    "Accept": "*/*",
    "Accept-Language": "en-IN,en;q=0.9",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
  },
  {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "*/*",
  },
];

async function fetchCdn(url: string): Promise<{ status: number; contentType: string; buffer: ArrayBuffer }> {
  for (const headers of CDN_HEADER_VARIANTS) {
    const resp = await fetch(url, { headers });
    if (resp.status !== 403) {
      return {
        status: resp.status,
        contentType: resp.headers.get("content-type") || "application/octet-stream",
        buffer: await resp.arrayBuffer(),
      };
    }
  }
  // All variants returned 403 — return the last 403
  return { status: 403, contentType: "application/json", buffer: new ArrayBuffer(0) };
}

function isAllowedPdfHost(hostname: string): boolean {
  return PDF_HOSTS.some((h) => hostname === h || hostname.endsWith(`.${h}`));
}

// ── pwmarco video URL proxy ───────────────────────────────────────────────────
proxyRouter.get("/pwmarco-video-url", async (req, res) => {
  const { batchId, childId, subjectId } = req.query as Record<string, string>;
  const url = `https://m.pwmarco.site/api/get-video-url?batchId=${batchId}&childId=${childId}&subjectId=${subjectId}&urlType=penpencilvdo`;
  try {
    const upstream = await fetch(url);
    const data = await upstream.json();
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ── pwmarco stream URL proxy ───────────────────────────────────────────────────
proxyRouter.get("/pwmarco-stream-url", async (req, res) => {
  const query = new URLSearchParams(req.query as any).toString();
  const url = `https://m.pwmarco.site/api/stream-url?${query}`;
  try {
    const upstream = await fetch(url);
    const data = await upstream.json();
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ── Vidcloud stream URL extractor ─────────────────────────────────────────────
// Fetches vidcloud's play.php page (which has PW auth baked in) and extracts
// any CloudFront signed MPD/HLS/M3U8 URLs embedded in the page source.
proxyRouter.get("/vidcloud-stream", async (req, res) => {
  const { batchId, subjectId, videoId } = req.query as Record<string, string>;
  if (!batchId || !videoId) {
    res.status(400).json({ error: "Missing batchId or videoId" });
    return;
  }

  const vidcloudUrl = `https://vidcloud.eu.org/play.php?batch_id=${encodeURIComponent(batchId)}&subject_id=${encodeURIComponent(subjectId || "")}&video_id=${encodeURIComponent(videoId)}&video_type=new`;

  try {
    const upstream = await fetch(vidcloudUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
        "Referer": "https://www.pw.live/",
      },
    });

    const html = await upstream.text();

    // Extract any CloudFront or CDN video URLs embedded in the page
    const patterns = [
      // Signed CloudFront URL with Policy/Signature params
      /https?:\/\/[^"'\s]+cloudfront\.net[^"'\s]*(?:\.mpd|\.m3u8|\.master)[^"'\s]*/gi,
      // Unsigned CloudFront MPD/HLS
      /https?:\/\/[^"'\s]+cloudfront\.net\/[^"'\s]+\.(?:mpd|m3u8)[^"'\s]*/gi,
      // PW CDN
      /https?:\/\/[^"'\s]+(?:pw\.live|mediacdn\.pw)[^"'\s]+\.(?:mpd|m3u8)[^"'\s]*/gi,
      // Any MPD/HLS in JSON-like strings
      /"(https?:\/\/[^"]+\.(?:mpd|m3u8)[^"]*)"/gi,
      /'(https?:\/\/[^']+\.(?:mpd|m3u8)[^']*)'/gi,
    ];

    const found = new Set<string>();
    for (const pattern of patterns) {
      let m: RegExpExecArray | null;
      while ((m = pattern.exec(html)) !== null) {
        found.add(m[1] ?? m[0]);
      }
    }

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.json({
      urls: [...found],
      // Also include the raw page length for debugging
      pageLength: html.length,
    });
  } catch (err) {
    req.log.error({ err }, "vidcloud-stream fetch failed");
    res.status(502).json({ error: "Failed to fetch vidcloud page" });
  }
});

// ── learnbyakp video-url proxy ───────────────────────────────────────────────
// Forwards to https://learnbyakp.onrender.com/api/video-url and returns the
// full JSON (url, directUrl, streamUrl, signedUrl, clearKeys, vid, topic).
proxyRouter.options("/akp-video-url", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.status(204).end();
});

proxyRouter.get("/akp-video-url", async (req, res) => {
  const { batchId, childId } = req.query as Record<string, string>;
  if (!batchId || !childId) {
    res.status(400).json({ error: "Missing batchId or childId" });
    return;
  }

  const upstream = `https://learnbyakp.onrender.com/api/video-url?batchId=${encodeURIComponent(batchId)}&childId=${encodeURIComponent(childId)}`;

  try {
    const resp = await fetch(upstream, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "application/json, */*",
        "Referer": "https://learnbyakp.online/",
        "Origin": "https://learnbyakp.online",
      },
    });

    const data = await resp.json();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=300");
    res.status(resp.status).json(data);
  } catch (err) {
    req.log.error({ err }, "akp-video-url proxy fetch failed");
    res.status(502).json({ error: "Upstream fetch failed" });
  }
});

// ── PW lecture slides + attachments ─────────────────────────────────────────
// Keeps the browser independent of the upstream API's CORS and normalizes the
// two schedule endpoints into the small shape the video player needs.
const OBJECT_ID = /^[a-f\d]{24}$/i;

function pwAssetUrl(asset: any, fallback?: string): string {
  if (asset?.baseUrl && asset?.key) return `${asset.baseUrl}${asset.key}`;
  if (asset?.url && /^https?:\/\//i.test(asset.url)) return asset.url;
  if (fallback && /^https?:\/\//i.test(fallback)) return fallback;
  if (fallback) return `https://static.pw.live/${fallback.replace(/^\/+/, "")}`;
  return "";
}

function normalizeSlide(slide: any) {
  const timestamp = Number.parseFloat(String(slide?.timeStamp ?? slide?.timestamp ?? ""));
  const imageUrl = pwAssetUrl(slide?.img, slide?.imageUrl);
  if (!Number.isFinite(timestamp) || !imageUrl) return null;
  return {
    id: String(slide?._id ?? `${slide?.serialNumber ?? "slide"}-${timestamp}`),
    name: String(slide?.name ?? `Slide ${slide?.serialNumber ?? ""}`).trim(),
    serialNumber: Number(slide?.serialNumber ?? 0),
    timestamp,
    imageUrl,
  };
}

function normalizeAttachments(schedule: any) {
  const homework = [
    ...(Array.isArray(schedule?.homeworkIds) ? schedule.homeworkIds : []),
    ...(Array.isArray(schedule?.dpp?.homeworkIds) ? schedule.dpp.homeworkIds : []),
  ];
  const seen = new Set<string>();
  const attachments: Array<{ id: string; title: string; name: string; url: string }> = [];

  for (const item of homework) {
    // Some responses only contain homework ids. There is no usable file URL
    // in that form, so skip those entries rather than rendering dead links.
    if (!item || typeof item !== "object") continue;
    for (const attachment of Array.isArray(item.attachmentIds) ? item.attachmentIds : []) {
      const url = pwAssetUrl(attachment);
      if (!url || seen.has(url)) continue;
      seen.add(url);
      attachments.push({
        id: String(attachment?._id ?? url),
        title: String(item.topic ?? item.note ?? attachment?.name ?? "Attachment").trim(),
        name: String(attachment?.name ?? item.note ?? "Open attachment").trim(),
        url,
      });
    }
  }
  return attachments;
}

proxyRouter.options("/pw-schedule-assets", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.status(204).end();
});

proxyRouter.get("/pw-schedule-assets", async (req, res) => {
  const { batchId, subjectId, scheduleId } = req.query as Record<string, string>;
  if (!OBJECT_ID.test(batchId ?? "") || !OBJECT_ID.test(subjectId ?? "") || !OBJECT_ID.test(scheduleId ?? "")) {
    res.status(400).json({ success: false, error: "Invalid batch, subject, or schedule id" });
    return;
  }

  const apiBase = `${await getPwApiUrl()}/v1`;
  const base = `${apiBase}/batches/${batchId}/subject/${subjectId}/schedule/${scheduleId}`;
  try {
    const [slidesResponse, detailsResponse] = await Promise.all([
      fetch(`${base}/slides`, { headers: { Accept: "application/json" } }),
      fetch(`${base}/schedule-details`, { headers: { Accept: "application/json" } }),
    ]);
    if (!slidesResponse.ok || !detailsResponse.ok) {
      res.status(502).json({ success: false, error: "Lecture resources are unavailable" });
      return;
    }

    const [slidesJson, detailsJson] = await Promise.all([
      slidesResponse.json() as Promise<any>,
      detailsResponse.json() as Promise<any>,
    ]);
    const slideSource = slidesJson?.data?.slides ?? slidesJson?.slides ?? [];
    const slides = (Array.isArray(slideSource) ? slideSource : [])
      .filter((slide: any) => slide?.slideForTimeline !== false)
      .map(normalizeSlide)
      .filter(Boolean)
      .sort((a: any, b: any) => a.timestamp - b.timestamp);
    const schedule = detailsJson?.data ?? detailsJson;

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=300");
    res.json({
      success: true,
      data: {
        slides,
        attachments: normalizeAttachments(schedule),
        topic: schedule?.topic ?? "",
      },
    });
  } catch (err) {
    req.log.error({ err }, "PW schedule assets proxy failed");
    res.status(502).json({ success: false, error: "Failed to load lecture resources" });
  }
});

// ── Direct video download proxy ──────────────────────────────────────────────
// Manifest/DRM URLs are intentionally not accepted here. The player only calls
// this route when the upstream API exposes a real media file URL.
proxyRouter.get("/video-download", async (req, res) => {
  const rawUrl = req.query.url as string | undefined;
  const requestedName = req.query.filename as string | undefined;
  if (!rawUrl) {
    res.status(400).json({ error: "Missing video URL" });
    return;
  }

  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    res.status(400).json({ error: "Invalid video URL" });
    return;
  }

  if (!isAllowedCdnHost(parsed.hostname) || !/\.(mp4|webm|mov|m4v|mkv)$/i.test(parsed.pathname)) {
    res.status(403).json({ error: "Only direct media files can be downloaded" });
    return;
  }

  try {
    let upstream: Response | null = null;
    for (const headers of CDN_HEADER_VARIANTS) {
      const response = await fetch(parsed, { headers });
      if (response.status !== 403) {
        upstream = response;
        break;
      }
    }
    if (!upstream || !upstream.ok || !upstream.body) {
      res.status(upstream?.status || 502).json({ error: "Video download failed" });
      return;
    }

    const safeName = (requestedName || "pwx-video.mp4")
      .replace(/[^a-zA-Z0-9._-]/g, "_")
      .slice(0, 120);
    res.status(200);
    res.setHeader("Content-Type", upstream.headers.get("content-type") || "application/octet-stream");
    const contentLength = upstream.headers.get("content-length");
    if (contentLength) res.setHeader("Content-Length", contentLength);
    res.setHeader("Content-Disposition", `attachment; filename="${safeName}"`);
    Readable.fromWeb(upstream.body as any).pipe(res);
  } catch (err) {
    req.log.error({ err }, "video download proxy failed");
    if (!res.headersSent) res.status(502).json({ error: "Video download failed" });
  }
});

// ── PW video metadata proxy (fetches from pwsecure with proper headers) ────────
proxyRouter.get("/pw-video/:videoId", async (req, res) => {
  const { videoId } = req.params as { videoId: string };
  if (!videoId) {
    res.status(400).json({ error: "Missing videoId" });
    return;
  }

  const PW_SECURE = await getPwApiUrl();
  const url = `${PW_SECURE}/v1/videos/${encodeURIComponent(videoId)}`;

  try {
    const upstream = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Referer": "https://www.pw.live/",
        "Origin": "https://www.pw.live",
        "Accept": "application/json, text/plain, */*",
      },
    });

    const data = await upstream.json();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=300");
    res.status(upstream.status).json(data);
  } catch (err) {
    req.log.error({ err }, "pw-video proxy fetch failed");
    res.status(502).json({ error: "Upstream fetch failed" });
  }
});

proxyRouter.options(["/proxy", "/pdf", "/dash-seg/*path"], (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.status(204).end();
});

proxyRouter.get("/pdf", async (req, res) => {
  const rawUrl = req.query.url as string | undefined;
  if (!rawUrl) {
    res.status(400).json({ error: "Missing url" });
    return;
  }

  let fullUrl = rawUrl;
  if (!fullUrl.startsWith("http")) fullUrl = `https://${fullUrl}`;

  let parsed: URL;
  try {
    parsed = new URL(fullUrl);
  } catch {
    res.status(400).json({ error: "Invalid URL" });
    return;
  }

  if (!isAllowedPdfHost(parsed.hostname)) {
    res.status(403).json({ error: "Host not allowed" });
    return;
  }

  try {
    const upstream = await fetch(fullUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; PWX/1.0)",
        "Referer": "https://www.pw.live/",
        "Origin": "https://www.pw.live",
      },
    });

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("Content-Disposition", "inline");
    res.status(upstream.status);

    const buf = await upstream.arrayBuffer();
    res.end(Buffer.from(buf));
  } catch (err) {
    req.log.error({ err }, "pdf proxy fetch failed");
    res.status(502).json({ error: "Upstream fetch failed" });
  }
});

proxyRouter.get("/proxy", async (req, res) => {
  const rawUrl = req.query.url as string | undefined;
  if (!rawUrl) {
    res.status(400).json({ error: "Missing url" });
    return;
  }

  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    res.status(400).json({ error: "Invalid URL" });
    return;
  }

  if (!isAllowedCdnHost(parsed.hostname)) {
    res.status(403).json({ error: "Host not allowed" });
    return;
  }

  const isMpd =
    rawUrl.includes(".mpd") ||
    rawUrl.includes(".m3u8") ||
    rawUrl.includes(".xml");

  if (isMpd) {
    try {
      const { status, contentType, buffer } = await fetchCdn(rawUrl);
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      res.status(status);

      if (status < 300) {
        const mpdText = new TextDecoder().decode(buffer);
        res.setHeader("Content-Type", "application/dash+xml");
        
        // Extract the absolute base path from the original URL (e.g., https://host/path/to/)
        const basePath = rawUrl.substring(0, rawUrl.lastIndexOf("/") + 1);
        
        // Inject the absolute original BaseURL into the MPD.
        const rewritten = injectBaseUrl(mpdText, basePath);
        res.end(rewritten);
      } else {
        res.setHeader("Content-Type", contentType);
        res.end(Buffer.from(buffer));
      }
    } catch (err) {
      req.log.error({ err }, "proxy MPD fetch failed");
      res.status(502).json({ error: "Upstream fetch failed" });
    }
  } else {
    // For large video segments (.m4s, .mp4, .ts), stream directly instead of buffering in memory
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    
    try {
      let upstream = await fetch(rawUrl, { headers: CDN_HEADER_VARIANTS[0] });
      if (upstream.status === 403) {
        upstream = await fetch(rawUrl, { headers: CDN_HEADER_VARIANTS[1] });
      }
      
      res.status(upstream.status);
      res.setHeader("Content-Type", upstream.headers.get("content-type") || "video/mp4");
      
      if (upstream.body) {
        upstream.body.pipe(res);
      } else {
        res.end();
      }
    } catch (err) {
      req.log.error({ err }, "proxy segment fetch failed");
      res.status(502).end();
    }
  }
});

proxyRouter.get("/dash-seg/:sig/{*path}", async (req, res) => {
  const { sig, path: pathParam } = req.params as unknown as { sig: string; path: string };

  let sigQs: string;
  try {
    sigQs = Buffer.from(sig, "base64url").toString();
  } catch {
    res.status(400).json({ error: "Invalid sig" });
    return;
  }

  const segPath = Array.isArray(pathParam) ? pathParam.join("/") : pathParam;
  const cdnUrl = `https://sec-prod-mediacdn.pw.live/${segPath}?${sigQs}`;

  let parsed: URL;
  try {
    parsed = new URL(cdnUrl);
  } catch {
    res.status(400).json({ error: "Bad segment URL" });
    return;
  }

  if (!isAllowedCdnHost(parsed.hostname)) {
    res.status(403).json({ error: "Host not allowed" });
    return;
  }

  // Stream segments directly — avoids buffering entire segment on server before sending
  for (const headers of CDN_HEADER_VARIANTS) {
    try {
      const upstream = await fetch(cdnUrl, { headers });
      if (upstream.status === 403) continue;

      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      res.setHeader("Content-Type", upstream.headers.get("content-type") || "application/octet-stream");
      res.setHeader("Cache-Control", "public, max-age=3600, immutable");
      const cl = upstream.headers.get("content-length");
      if (cl) res.setHeader("Content-Length", cl);
      res.status(upstream.status);

      if (upstream.body) {
        Readable.fromWeb(upstream.body as any).pipe(res);
      } else {
        res.end();
      }
      return;
    } catch (err) {
      req.log.error({ err }, "dash-seg stream attempt failed");
    }
  }

  res.status(502).json({ error: "Segment fetch failed" });
});

// ── RareStudy PDF proxy ──────────────────────────────────────────────────────
proxyRouter.options("/rarestudy-pdf", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.status(204).end();
});

proxyRouter.get("/rarestudy-pdf", async (req, res) => {
  const { batchId, subjectId, scheduleId, noteIndex = "0", isDpp = "false" } = req.query as Record<string, string>;

  if (!batchId || !subjectId || !scheduleId) {
    res.status(400).json({ error: "Missing required params" });
    return;
  }

  const url = `https://rarestudy.in/schedule-details?batchId=${encodeURIComponent(batchId)}&subjectId=${encodeURIComponent(subjectId)}&scheduleId=${encodeURIComponent(scheduleId)}&tap=note&noteIndex=${encodeURIComponent(noteIndex)}&isDpp=${encodeURIComponent(isDpp)}`;

  try {
    const upstream = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Referer": "https://rarestudy.in/",
        "Origin": "https://rarestudy.in",
        "Accept": "application/json, text/plain, */*",
      },
    });

    const data = await upstream.json();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=1800");
    res.status(upstream.status).json(data);
  } catch (err) {
    req.log.error({ err }, "rarestudy-pdf fetch failed");
    res.status(502).json({ error: "Upstream fetch failed" });
  }
});

// ── Google Drive proxy (bypasses referrer restriction) ──────────────────────
const DRIVE_API_KEY = process.env.DRIVE_API_KEY ?? "";

proxyRouter.get("/drive/files", async (req, res) => {
  if (!DRIVE_API_KEY) {
    res.status(503).json({ error: "Drive API not configured" });
    return;
  }

  const { folderId } = req.query as { folderId?: string };
  if (!folderId) {
    res.status(400).json({ error: "Missing folderId" });
    return;
  }

  const q = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
  const fields = encodeURIComponent("files(id,name,mimeType,modifiedTime,size)");
  const url = `https://www.googleapis.com/drive/v3/files?q=${q}&fields=${fields}&key=${DRIVE_API_KEY}&orderBy=folder,name&pageSize=200`;

  try {
    const upstream = await fetch(url, {
      headers: {
        "Referer": "https://materialforjee.onrender.com/",
        "Origin": "https://materialforjee.onrender.com",
        "User-Agent": "Mozilla/5.0 (compatible; PWX/1.0)",
      },
    });

    const data = await upstream.json();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", "public, max-age=300");
    res.status(upstream.status).json(data);
  } catch (err) {
    req.log.error({ err }, "drive proxy fetch failed");
    res.status(502).json({ error: "Drive API fetch failed" });
  }
});

// ── Streama HLS proxy (bypasses CORS/IP blocks on streama.pimaxer.in) ──────
// Cloudflare Pages IPs are blocked by streama, so we route through Render.
const STREAMA_HOST = "streama.pimaxer.in";

proxyRouter.options("/streama-proxy", (_req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "*");
  res.status(204).end();
});

proxyRouter.get("/streama-proxy", async (req, res) => {
  const rawUrl = req.query.url as string | undefined;
  if (!rawUrl) {
    res.status(400).json({ error: "Missing url param" });
    return;
  }

  let fullUrl = rawUrl;
  if (!fullUrl.startsWith("http")) fullUrl = `https://${STREAMA_HOST}/${fullUrl.replace(/^\//, "")}`;

  let parsed: URL;
  try {
    parsed = new URL(fullUrl);
  } catch (e) {
    req.log.error({ rawUrl, err: e }, "streama-proxy: invalid URL");
    res.status(400).json({ error: "Invalid URL" });
    return;
  }

  if (parsed.hostname !== STREAMA_HOST) {
    res.status(403).json({ error: "Only streama.pimaxer.in is allowed" });
    return;
  }

  try {
    req.log.info({ url: fullUrl }, "streama-proxy: fetching");
    const upstream = await fetch(fullUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Origin": "http://localhost:5000",
        "Referer": "http://localhost:5000/",
        "Accept": "*/*",
      },
    });

    const contentType = upstream.headers.get("content-type") || "application/octet-stream";
    const isM3u8 = fullUrl.endsWith(".m3u8") || contentType.toLowerCase().includes("mpegurl");

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "*");
    // Do not cache .m3u8 files on the proxy to prevent stale rewrites, but cache segments
    if (!isM3u8) {
      res.setHeader("Cache-Control", "public, max-age=3600");
    } else {
      res.setHeader("Cache-Control", "no-cache");
    }

    res.status(upstream.status);
    res.setHeader("Content-Type", contentType);

    if (isM3u8) {
      let buf = Buffer.from(await upstream.arrayBuffer());
      const text = buf.toString("utf-8");
      const rewritten = text.split("\n").map(line => {
        const trimmed = line.trim();
        if (trimmed && !trimmed.startsWith("#") && !trimmed.startsWith("http")) {
          try {
            return new URL(trimmed, fullUrl).href;
          } catch {
            return line;
          }
        }
        return line;
      }).join("\n");
      buf = Buffer.from(rewritten, "utf-8");
      res.setHeader("Content-Length", buf.length);
      res.end(buf);
    } else {
      const cl = upstream.headers.get("content-length");
      if (cl) res.setHeader("Content-Length", cl);

      if (upstream.body) {
        const reader = upstream.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(value);
        }
        res.end();
      } else {
        const buf = Buffer.from(await upstream.arrayBuffer());
        res.end(buf);
      }
    }
  } catch (err) {
    req.log.error({ err, url: fullUrl }, "streama-proxy fetch failed");
    if (!res.headersSent) res.status(502).json({ error: "Upstream fetch failed" });
  }
});


export default proxyRouter;
